package com.chesshack

import android.graphics.Bitmap
import android.graphics.RectF

object Vision {

    data class Obs(val occ: Long, val white: Long)

    private val CACHE = IntArray(600 * 600)

    fun analyze(bmp: Bitmap, board: RectF, flipped: Boolean): Obs {
        var occ = 0L
        var wht = 0L
        val cw = board.width() / 8f
        val ch = board.height() / 8f

        for (sq in 0 until 64) {
            val f = sq % 8
            val r = sq / 8
            val col = if (!flipped) f else 7 - f
            val row = if (!flipped) 7 - r else r
            val info = square(bmp, board.left + col * cw, board.top + row * ch, cw, ch)
            if (info.occupied) occ = occ or (1L shl sq)
            if (info.isWhite) wht = wht or (1L shl sq)
        }
        return Obs(occ, wht)
    }

    private class Sq(val occupied: Boolean, val isWhite: Boolean)

    private fun square(bmp: Bitmap, x0: Float, y0: Float, w: Float, h: Float): Sq {
        val iw = w.toInt().coerceIn(8, 500)
        val ih = h.toInt().coerceIn(8, 500)
        if (iw * ih > CACHE.size) return Sq(false, false)
        val x = x0.toInt(); val y = y0.toInt()
        if (x < 0 || y < 0 || x + iw > bmp.width || y + ih > bmp.height) return Sq(false, false)

        try { bmp.getPixels(CACHE, 0, iw, x, y, iw, ih) } catch (t: Throwable) {
            return Sq(false, false)
        }

        val pw = (iw * 0.18f).toInt().coerceAtLeast(3)
        val ph = (ih * 0.18f).toInt().coerceAtLeast(3)

        fun lum(px: Int): Double {
            val c = CACHE[px]
            return 0.299 * ((c shr 16) and 0xff) +
                   0.587 * ((c shr 8) and 0xff) +
                   0.114 * (c and 0xff)
        }
        fun patchMean(px: Int, py: Int): Double {
            var s = 0.0; var n = 0
            for (yy in py until (py + ph).coerceAtMost(ih))
                for (xx in px until (px + pw).coerceAtMost(iw)) { s += lum(yy * iw + xx); n++ }
            return if (n == 0) 0.0 else s / n
        }

        val bg = (patchMean(1, 1) + patchMean(iw - pw - 1, 1) +
                  patchMean(1, ih - ph - 1) + patchMean(iw - pw - 1, ih - ph - 1)) / 4.0

        var lighter = 0; var darker = 0; var total = 0
        val step = (iw / 26).coerceAtLeast(1)
        val xA = (iw * 0.12f).toInt(); val xB = (iw * 0.88f).toInt()
        val yA = (ih * 0.12f).toInt(); val yB = (ih * 0.88f).toInt()
        var yy = yA
        while (yy < yB) {
            var xx = xA
            while (xx < xB) {
                val d = lum(yy * iw + xx) - bg
                if (d > 26) lighter++ else if (d < -26) darker++
                total++; xx += step
            }
            yy += step
        }
        if (total == 0) return Sq(false, false)
        return Sq((lighter + darker) > total * 0.09, lighter > darker)
    }
}
