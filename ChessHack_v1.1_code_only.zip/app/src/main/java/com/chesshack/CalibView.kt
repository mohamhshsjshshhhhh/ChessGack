package com.chesshack

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View

class CalibView(
    ctx: Context,
    private val prefs: Prefs,
    private val done: (RectF) -> Unit
) : View(ctx) {

    private var a: PointF? = null
    private var b: PointF? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.parseColor("#2EE59D")
        strokeWidth = 6f * resources.displayMetrics.density
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 42f; typeface = Typeface.DEFAULT_BOLD
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#66000000"))
        canvas.drawText("دوس على ركن البورد فوق-شمال", 60f, 160f, txt)
        canvas.drawText("وبعدين تحت-يمين", 60f, 220f, txt)
        val x = a; val y = b
        if (x != null && y != null) {
            canvas.drawRect(x.x, x.y, y.x, y.y, p)
            val w = (y.x - x.x) / 8f; val h = (y.y - x.y) / 8f
            for (i in 1..7) {
                canvas.drawLine(x.x + i * w, x.y, x.x + i * w, y.y, p)
                canvas.drawLine(x.x, x.y + i * h, y.x, y.y + i * h, p)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) {
            if (a == null || b != null) { a = PointF(e.x, e.y); b = null }
            else {
                val p0 = a!!
                b = PointF(e.x, e.y)
                val r = RectF(minOf(p0.x, e.x), minOf(p0.y, e.y),
                              maxOf(p0.x, e.x), maxOf(p0.y, e.y))
                if (r.width() > 120 && r.height() > 120) postDelayed({ done(r) }, 250)
            }
            invalidate()
        }
        return true
    }
}
