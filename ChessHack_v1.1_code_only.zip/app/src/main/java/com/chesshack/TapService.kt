package com.chesshack

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class TapService : AccessibilityService() {

    companion object { @Volatile var instance: TapService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun drag(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long, done: (() -> Unit)? = null) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done?.invoke() }
            override fun onCancelled(g: GestureDescription?) {}
        }, null)
    }

    fun tapPromotion(piece: String) {
        val root = rootInActiveWindow ?: return
        val n = root.findAccessibilityNodeInfosByText(piece)
            .firstOrNull { it.isVisibleToUser } ?: return
        val r = android.graphics.Rect()
        n.getBoundsInScreen(r)
        val p = Path().apply {
            moveTo(r.exactCenterX(), r.exactCenterY())
            lineTo(r.exactCenterX(), r.exactCenterY())
        }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 40))
            .build(), null, null)
    }
}
