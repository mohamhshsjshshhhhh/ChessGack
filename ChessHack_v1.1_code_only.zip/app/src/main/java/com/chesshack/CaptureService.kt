package com.chesshack

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

/** آخر فريم من الشاشة */
object Frames {
    @Volatile var reader: ImageReader? = null
    @Volatile private var last: Bitmap? = null
    @Volatile var w = 0
    @Volatile var h = 0

    fun grab(): Bitmap? {
        val r = reader ?: return last
        var img: android.media.Image? = null
        try {
            img = r.acquireLatestImage() ?: return last
            val p = img.planes[0]
            val iw = img.width
            val ih = img.height
            val pixelStride = p.pixelStride
            val rowPad = p.rowStride - pixelStride * iw
            val bufW = iw + rowPad / pixelStride

            val bmp = Bitmap.createBitmap(bufW, ih, Bitmap.Config.ARGB_8888)
            p.buffer.rewind()
            bmp.copyPixelsFromBuffer(p.buffer)
            last = if (rowPad == 0) bmp
                   else Bitmap.createBitmap(bmp, 0, 0, iw, ih)
        } catch (t: Throwable) {
            // نرجّع آخر فريم سليم
        } finally {
            try { img?.close() } catch (_: Throwable) {}
        }
        return last
    }
}

class CaptureService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        fun start(ctx: Context, code: Int, data: Intent) {
            val i = Intent(ctx, CaptureService::class.java)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_DATA, data)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i)
            else ctx.startService(i)
        }
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(
                NotificationChannel("cap", "Capture", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, "cap")
            .setContentTitle("Chess Hack")
            .setContentText("بيقرا الشاشة")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()

        if (Build.VERSION.SDK_INT >= 29)
            startForeground(7, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(7, notif)

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA) ?: return START_NOT_STICKY

        val mp = getSystemService(MediaProjectionManager::class.java)
            .getMediaProjection(code, data)
        projection = mp

        val wm = getSystemService(WindowManager::class.java)
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)

        val reader = ImageReader.newInstance(
            metrics.widthPixels, metrics.heightPixels, PixelFormat.RGBA_8888, 2)
        vd = mp.createVirtualDisplay(
            "chesscap", metrics.widthPixels, metrics.heightPixels, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null)
        Frames.reader = reader
        Frames.w = metrics.widthPixels
        Frames.h = metrics.heightPixels

        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { Frames.reader = null }
        }, null)

        return START_STICKY
    }

    override fun onDestroy() {
        try { vd?.release() } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        Frames.reader = null
        super.onDestroy()
    }
}
