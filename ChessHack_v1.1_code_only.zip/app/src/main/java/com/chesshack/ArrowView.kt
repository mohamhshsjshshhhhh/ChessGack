package com.chesshack

import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.view.View
import kotlin.math.hypot

class ArrowView(ctx: Context) : View(ctx) {

    private var from: PointF? = null
    private var to: PointF? = null
    var cellSize = 40f
    private var pulse = 1f

    private val green = Color.parseColor("#2EE59D")
    private val amber = Color.parseColor("#FFC24B")

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    fun show(a: PointF, b: PointF) { from = a; to = b; invalidate() }
    fun hide() { from = null; to = null; invalidate() }

    fun pulseOn() {
        val anim = android.animation.ValueAnimator.ofFloat(0.6f, 1f).apply {
            duration = 900
            repeatCount = android.animation.ValueAnimator.INFINITE
            repeatMode = android.animation.ValueAnimator.REVERSE
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val a = from ?: return
        val b = to ?: return
        val d = resources.displayMetrics.density
        val sq = 0.44f * cellSize.coerceIn(20f, 200f)

        ring(canvas, a, sq * 0.62f, green)
        ring(canvas, b, sq * 0.62f, amber)

        val dx = b.x - a.x; val dy = b.y - a.y
        val len = hypot(dx, dy)
        if (len < 4) return
        val ux = dx / len; val uy = dy / len
        val startR = sq * 0.62f
        val headLen = (len * 0.24f).coerceIn(18 * d, 34 * d)
        val headW = headLen * 0.62f

        val sx = a.x + ux * startR; val sy = a.y + uy * startR
        val ex = b.x - ux * headLen * 0.9f; val ey = b.y - uy * headLen * 0.9f

        stroke.color = Color.argb((210 * pulse).toInt(), 46, 229, 157)
        stroke.strokeWidth = 11f * d
        canvas.drawLine(sx, sy, ex, ey, stroke)

        val head = Path().apply {
            moveTo(b.x, b.y)
            lineTo(ex - uy * headW, ey + ux * headW)
            lineTo(ex + uy * headW, ey - ux * headW)
            close()
        }
        fill.color = Color.argb((235 * pulse).toInt(), 46, 229, 157)
        canvas.drawPath(head, fill)
    }

    private fun ring(c: Canvas, p: PointF, r: Float, color: Int) {
        stroke.color = Color.argb((230 * pulse).toInt(),
            Color.red(color), Color.green(color), Color.blue(color))
        stroke.strokeWidth = 7f * resources.displayMetrics.density
        c.drawCircle(p.x, p.y, r, stroke)
    }
}
