package com.chesshack

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class UciEngine(private val ctx: Context) {

    private var proc: Process? = null
    private var out: BufferedWriter? = null
    private var inp: BufferedReader? = null
    private val lock = Any()

    fun start() {
        if (proc != null) return
        val bin = File(ctx.applicationInfo.nativeLibraryDir, "libstockfish.so")
        if (!bin.exists()) throw IllegalStateException("libstockfish.so مش موجود في jniLibs")

        val pb = ProcessBuilder(bin.absolutePath)
        pb.redirectErrorStream(true)
        val p = pb.start()
        proc = p
        out = BufferedWriter(OutputStreamWriter(p.outputStream))
        inp = BufferedReader(InputStreamReader(p.inputStream))

        send("uci"); waitFor("uciok", 4000)

        val cores = Runtime.getRuntime().availableProcessors()
        setOption("Threads", (cores / 2).coerceAtLeast(2).toString())
        setOption("Hash", "256")
        nnuePath()?.let { setOption("EvalFile", it) }
        send("ucinewgame")
        isReady()
    }

    private fun nnuePath(): String? {
        val assets = ctx.assets.list("")?.toList() ?: emptyList()
        val name = assets.firstOrNull { it.endsWith(".nnue") } ?: return null
        val f = File(ctx.filesDir, name)
        if (!f.exists())
            ctx.assets.open(name).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f.absolutePath
    }

    fun setOption(name: String, value: String) = send("setoption name $name value $value")

    fun isReady() { send("isready"); waitFor("readyok", 10_000) }

    fun bestMove(fen: String, movetimeMs: Int): String? = synchronized(lock) {
        try {
            send("position fen $fen")
            send("go movetime $movetimeMs")
            while (true) {
                val line = inp?.readLine() ?: return null
                if (line.startsWith("bestmove")) {
                    val mv = line.split(" ").getOrNull(1) ?: return null
                    return if (mv == "(none)") null else mv
                }
            }
        } catch (e: Exception) { null }
    }

    private fun send(cmd: String) {
        try { out?.write(cmd + "\n"); out?.flush() } catch (_: IOException) {}
    }

    private fun waitFor(token: String, timeoutMs: Long): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val l = inp?.readLine() ?: return false
            if (l.contains(token)) return true
        }
        return false
    }

    fun stop() {
        try { send("quit"); proc?.waitFor() } catch (_: Throwable) {}
        proc = null; out = null; inp = null
    }
}
