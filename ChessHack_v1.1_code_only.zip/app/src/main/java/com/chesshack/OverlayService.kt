package com.chesshack

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PointF
import android.graphics.RectF
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.SeekBar
import android.widget.TextView
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import kotlin.math.roundToInt

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var left get() = sp.getFloat("l", -1f); set(v) = sp.edit().putFloat("l", v).apply()
    var top get() = sp.getFloat("t", -1f); set(v) = sp.edit().putFloat("t", v).apply()
    var right get() = sp.getFloat("r", -1f); set(v) = sp.edit().putFloat("r", v).apply()
    var bottom get() = sp.getFloat("b", -1f); set(v) = sp.edit().putFloat("b", v).apply()
    var flipped get() = sp.getBoolean("flip", false); set(v) = sp.edit().putBoolean("flip", v).apply()
    var playDelay get() = sp.getInt("delay", 600); set(v) = sp.edit().putInt("delay", v).apply()
    var movetime get() = sp.getInt("mt", 1200); set(v) = sp.edit().putInt("mt", v).apply()
    val hasBoard get() = left >= 0 && right > left
    fun rect() = RectF(left, top, right, bottom)
    fun save(r: RectF) { left = r.left; top = r.top; right = r.right; bottom = r.bottom }
}

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var panel: android.view.View
    private lateinit var pParams: LayoutParams
    private lateinit var arrow: ArrowView
    private lateinit var aParams: LayoutParams
    private lateinit var status: TextView
    private lateinit var btnAuto: TextView

    private var engine: UciEngine? = null
    private var tracker: Tracker? = null
    @Volatile private var running = false
    private var auto = false
    private var calib: CalibView? = null
    private var lastPlayAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WindowManager::class.java)
        prefs = Prefs(this)

        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(
                NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        startForeground(9, Notification.Builder(this, "ov")
            .setContentTitle("Chess Hack")
            .setContentText("شغال")
            .setSmallIcon(android.R.drawable.ic_menu_edit)
            .build())

        arrow = ArrowView(this)
        aParams = LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY
            else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or
            LayoutParams.FLAG_NOT_TOUCHABLE or
            LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT)
        wm.addView(arrow, aParams)
        arrow.pulseOn()

        panel = LayoutInflater.from(this).inflate(R.layout.panel, null)
        pParams = LayoutParams(
            LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY
            else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT)
        pParams.gravity = Gravity.TOP or Gravity.START
        pParams.x = 40; pParams.y = 300
        wm.addView(panel, pParams)

        status = panel.findViewById(R.id.status)
        btnAuto = panel.findViewById(R.id.btnAuto)

        bind()
        startEngine()
        tickSoon()
    }

    private fun bind() {
        val header = panel.findViewById<android.view.View>(R.id.header)
        var dx = 0f; var dy = 0f; var px = 0; var py = 0
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; px = pParams.x; py = pParams.y; true }
                MotionEvent.ACTION_MOVE -> {
                    pParams.x = px + (e.rawX - dx).roundToInt()
                    pParams.y = py + (e.rawY - dy).roundToInt()
                    wm.updateViewLayout(panel, pParams); true
                }
                else -> true
            }
        }

        panel.findViewById<android.view.View>(R.id.btnBest).setOnClickListener { hintOnce() }
        btnAuto.setOnClickListener { auto = !auto; styleAuto() }
        panel.findViewById<android.view.View>(R.id.close).setOnClickListener { stopSelf() }

        val seekSpeed = panel.findViewById<SeekBar>(R.id.seekSpeed)
        val lblSpeed = panel.findViewById<TextView>(R.id.lblSpeed)
        seekSpeed.max = 1800
        seekSpeed.progress = (prefs.playDelay - 200).coerceIn(0, 1800)
        lblSpeed.text = "سرعة اللعب: ${prefs.playDelay}ms"
        seekSpeed.setOnSeekBarChangeListener(simple { v ->
            prefs.playDelay = v + 200
            lblSpeed.text = "سرعة اللعب: ${prefs.playDelay}ms"
        })

        val seekThink = panel.findViewById<SeekBar>(R.id.seekThink)
        val lblThink = panel.findViewById<TextView>(R.id.lblThink)
        seekThink.max = 2800
        seekThink.progress = (prefs.movetime - 200).coerceIn(0, 2800)
        lblThink.text = "قوة التفكير: ${prefs.movetime}ms"
        seekThink.setOnSeekBarChangeListener(simple { v ->
            prefs.movetime = v + 200
            lblThink.text = "قوة التفكير: ${prefs.movetime}ms"
        })

        panel.findViewById<android.view.View>(R.id.chipSide).setOnClickListener { v ->
            prefs.flipped = !prefs.flipped
            (v as TextView).text = if (prefs.flipped) "أنا أسود" else "أنا أبيض"
            tracker = Tracker()
            arrow.hide()
        }
        panel.findViewById<android.view.View>(R.id.chipBoard).setOnClickListener { startCalibration() }
    }

    private fun simple(cb: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) cb(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun styleAuto() {
        btnAuto.text = if (auto) "إيقاف التلقائي" else "لعب تلقائي"
        btnAuto.setBackgroundResource(if (auto) R.drawable.bg_btn_on else R.drawable.bg_btn)
    }

    private fun startEngine() {
        status.text = "بيحمّل المحرك…"
        Thread {
            try {
                engine = UciEngine(this).also { it.start() }
                status.post { status.text = if (prefs.hasBoard) "جاهز" else "اضغط «حدد البورد»" }
            } catch (t: Throwable) {
                status.post { status.text = "المحرك فشل: ${t.message}" }
            }
        }.start()
    }

    private fun tickSoon() {
        if (running) return
        running = true
        Thread {
            while (running) {
                try { tick() } catch (t: Throwable) { }
                Thread.sleep(500)
            }
        }.start()
    }

    private fun mySide() = if (prefs.flipped) Side.BLACK else Side.WHITE

    private fun tick() {
        if (!prefs.hasBoard) return
        val bmp = Frames.grab() ?: return
        val rect = prefs.rect()
        val obs = Vision.analyze(bmp, rect, prefs.flipped)
        val t = tracker ?: Tracker().also { tracker = it }

        if (!t.sync(obs)) return
        if (t.board.sideToMove != mySide()) { arrow.post { arrow.hide() }; return }
        if (System.currentTimeMillis() - lastPlayAt < prefs.playDelay + 900) return

        val eng = engine ?: return
        val best = eng.bestMove(t.board.fen, prefs.movetime) ?: return
        val move = t.bestMoveUci(best) ?: return
        android.util.Log.d("ChessHack", "fen=${t.board.fen} best=$best")

        val f = fromPoint(rect, move.from, prefs.flipped)
        val to = fromPoint(rect, move.to, prefs.flipped)
        arrow.post { arrow.cellSize = rect.width() / 8f; arrow.show(f, to) }

        if (auto) {
            Thread.sleep(prefs.playDelay.toLong())
            lastPlayAt = System.currentTimeMillis()
            TapService.instance?.drag(f.x, f.y, to.x, to.y, 140L) {
                if (move.promotion != null && move.promotion != Piece.NONE)
                    TapService.instance?.tapPromotion("Queen")
            }
        }
    }

    private fun hintOnce() {
        if (!prefs.hasBoard) { status.text = "حدد البورد الأول"; return }
        Thread {
            val bmp = Frames.grab() ?: return@Thread
            val rect = prefs.rect()
            val obs = Vision.analyze(bmp, rect, prefs.flipped)
            val t = tracker ?: Tracker().also { tracker = it }
            t.sync(obs)
            val eng = engine ?: return@Thread
            val best = eng.bestMove(t.board.fen, prefs.movetime) ?: return@Thread
            val move = t.bestMoveUci(best) ?: return@Thread
            val a = fromPoint(rect, move.from, prefs.flipped)
            val b = fromPoint(rect, move.to, prefs.flipped)
            arrow.post {
                arrow.cellSize = rect.width() / 8f
                arrow.show(a, b)
                status.text = "أحسن نقلة: " + Tracker.uci(move)
            }
            Thread.sleep(8000)
            arrow.post { arrow.hide() }
        }.start()
    }

    private fun fromPoint(r: RectF, s: Square, flipped: Boolean): PointF {
        val f = s.ordinal % 8
        val rk = s.ordinal / 8
        val cw = r.width() / 8f
        val ch = r.height() / 8f
        val col = if (!flipped) f else 7 - f
        val row = if (!flipped) 7 - rk else rk
        return PointF(r.left + (col + 0.5f) * cw, r.top + (row + 0.5f) * ch)
    }

    private fun startCalibration() {
        if (calib != null) return
        val v = CalibView(this, prefs) { r ->
            prefs.save(r)
            wm.removeView(v)
            calib = null
            tracker = Tracker()
            status.text = "البورد اتحدد ✅"
        }
        calib = v
        wm.addView(v, LayoutParams(
            LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY
            else LayoutParams.TYPE_PHONE,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT))
    }

    override fun onDestroy() {
        running = false; auto = false
        try { wm.removeView(panel) } catch (_: Throwable) {}
        try { wm.removeView(arrow) } catch (_: Throwable) {}
        try { calib?.let { wm.removeView(it) } } catch (_: Throwable) {}
        engine?.stop()
        super.onDestroy()
    }
}
