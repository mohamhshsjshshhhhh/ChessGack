package com.chesshack

import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Move
import com.github.bhlangonijr.chesslib.Piece
import com.github.bhlangonijr.chesslib.Square

class Tracker {

    var board: Board = Board()
        private set

    fun sync(newObs: Vision.Obs): Boolean {
        if (dist(board, newObs) <= 1) return false

        var bestDist = Int.MAX_VALUE
        var bestPath: List<Move> = emptyList()
        val startFen = board.fen

        for (depth in 1..3) {
            val path = ArrayList<Move>()
            var found = false

            fun dfs(d: Int) {
                if (found) return
                val dd = dist(board, newObs)
                if (dd < bestDist) { bestDist = dd; bestPath = ArrayList(path) }
                if (dd == 0) { found = true; return }
                if (d == 0) return
                for (m in board.legalMoves.toList()) {
                    board.doMove(m); path.add(m)
                    dfs(d - 1)
                    path.removeAt(path.size - 1); board.undoMove()
                    if (found) return
                }
            }

            dfs(depth)
            if (bestDist <= 1) break
            board.loadFromFen(startFen)
        }

        if (bestDist > 2) return false
        for (m in bestPath) board.doMove(m)
        return bestPath.isNotEmpty()
    }

    private fun dist(b: Board, o: Vision.Obs): Int {
        var occ = 0L; var wht = 0L
        for (sq in Square.values()) {
            val p: Piece = b.getPiece(sq)
            if (p == Piece.NONE) continue
            val bit = 1L shl sq.ordinal
            occ = occ or bit
            if (p.pieceSide == com.github.bhlangonijr.chesslib.Side.WHITE) wht = wht or bit
        }
        return java.lang.Long.bitCount(occ xor o.occ) +
               java.lang.Long.bitCount(wht xor o.white)
    }

    fun bestMoveUci(uci: String): Move? =
        board.legalMoves.firstOrNull { uci(it).equals(uci, ignoreCase = true) }

    companion object {
        fun uci(m: Move): String {
            fun sq(s: Square): String =
                ('a'.code + (s.ordinal % 8)).toChar().toString() + (s.ordinal / 8 + 1)
            var s = sq(m.from) + sq(m.to)
            val promo = m.promotion
            if (promo != null && promo != Piece.NONE)
                s += promo.getName().first().lowercaseChar()
            return s
        }
    }
}
